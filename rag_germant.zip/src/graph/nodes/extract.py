"""
参数提取节点
从用户问题中提取关键参数(时间、党派、议员、主题等)
"""

import json
import re
from typing import Dict, Optional
from ...llm.client import GeminiLLMClient
from ...llm.prompts import PromptTemplates
from ...utils.logger import logger
from ..state import GraphState, update_state


class ExtractNode:
    """
    参数提取节点
    
    功能:
    1. 提取时间范围(年份、时间段)
    2. 提取党派名称
    3. 提取议员名称
    4. 提取主题和关键词
    
    输出:
    - parameters: 提取的参数字典
    """
    
    def __init__(self, llm_client: GeminiLLMClient = None):
        """
        初始化参数提取节点
        
        Args:
            llm_client: LLM客户端,如果为None则自动创建
        """
        self.llm = llm_client or GeminiLLMClient()
        self.prompts = PromptTemplates()
        
    def __call__(self, state: GraphState) -> GraphState:
        """
        执行参数提取
        
        Args:
            state: 当前状态
            
        Returns:
            更新后的状态
        """
        question = state["question"]
        logger.info(f"[ExtractNode] 开始提取参数: {question}")
        
        try:
            # 构建Prompt
            prompt = self.prompts.format_extraction_prompt(question)
            
            # 调用LLM
            response = self.llm.invoke(prompt)
            
            logger.debug(f"[ExtractNode] LLM响应: {response[:200]}...")
            
            # 解析响应
            parameters = self._parse_response(response)
            
            logger.info(f"[ExtractNode] 提取参数: {json.dumps(parameters, ensure_ascii=False, indent=2)}")
            
            # 判断是否需要拆解
            is_decomposed = self._need_decomposition(state, parameters)
            
            # 更新状态
            return update_state(
                state,
                parameters=parameters,
                is_decomposed=is_decomposed,
                current_node="extract",
                next_node="decompose" if is_decomposed else "retrieve"
            )
            
        except Exception as e:
            logger.error(f"[ExtractNode] 参数提取失败: {str(e)}")
            # 返回空参数,继续流程
            return update_state(
                state,
                parameters={},
                is_decomposed=False,
                current_node="extract",
                next_node="retrieve"
            )
    
    def _parse_response(self, response: str) -> Dict:
        """
        解析LLM响应,提取参数
        
        Args:
            response: LLM响应文本
            
        Returns:
            参数字典
        """
        # 尝试提取JSON
        try:
            # 查找JSON代码块
            json_match = re.search(r'```json\s*(\{.*?\})\s*```', response, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
            else:
                # 查找第一个完整的JSON对象
                json_match = re.search(r'\{.*\}', response, re.DOTALL)
                if json_match:
                    json_str = json_match.group(0)
                else:
                    json_str = response
            
            # 解析JSON
            parameters = json.loads(json_str)
            
            # 清理空值
            parameters = self._clean_parameters(parameters)
            
            return parameters
            
        except json.JSONDecodeError as e:
            logger.warning(f"[ExtractNode] JSON解析失败: {str(e)}, 使用规则提取")
            return self._rule_based_extraction(response)
    
    def _clean_parameters(self, params: Dict) -> Dict:
        """
        清理参数,移除空值和null
        
        Args:
            params: 原始参数
            
        Returns:
            清理后的参数
        """
        cleaned = {}
        
        for key, value in params.items():
            if isinstance(value, dict):
                cleaned_sub = {k: v for k, v in value.items() if v and v != "null"}
                if cleaned_sub:
                    cleaned[key] = cleaned_sub
            elif isinstance(value, list):
                cleaned_list = [v for v in value if v and v != "null"]
                if cleaned_list:
                    cleaned[key] = cleaned_list
            elif value and value != "null":
                cleaned[key] = value
        
        return cleaned
    
    def _rule_based_extraction(self, text: str) -> Dict:
        """
        基于规则的参数提取(备用方案)
        
        Args:
            text: 文本
            
        Returns:
            参数字典
        """
        params = {
            "time_range": {},
            "parties": [],
            "speakers": [],
            "topics": [],
            "keywords": []
        }
        
        # 提取年份
        years = re.findall(r'\b(19\d{2}|20\d{2})\b', text)
        if years:
            params["time_range"]["specific_years"] = list(set(years))
            if len(years) >= 2:
                params["time_range"]["start_year"] = min(years)
                params["time_range"]["end_year"] = max(years)
        
        # 提取常见党派
        parties = ["CDU/CSU", "SPD", "FDP", "GRÜNE", "DIE LINKE", "AfD"]
        for party in parties:
            if party in text:
                params["parties"].append(party)
        
        return params
    
    def _need_decomposition(self, state: GraphState, parameters: Dict) -> bool:
        """
        判断是否需要问题拆解
        
        Args:
            state: 当前状态
            parameters: 提取的参数
            
        Returns:
            是否需要拆解
        """
        # 如果是简单问题,不需要拆解
        if state.get("intent") == "simple":
            return False
        
        # 复杂问题的拆解条件
        question_type = state.get("question_type", "")
        
        # 变化类、对比类、总结类通常需要拆解
        if question_type in ["变化类", "对比类", "总结类"]:
            return True
        
        # 如果涉及多个维度,需要拆解
        time_range = parameters.get("time_range", {})
        parties = parameters.get("parties", [])
        
        # 多年份 + 多党派 = 需要拆解
        years = time_range.get("specific_years", [])
        if len(years) > 2 and len(parties) > 1:
            return True
        
        return False


if __name__ == "__main__":
    # 测试参数提取节点
    from ..state import create_initial_state, update_state
    
    # 测试复杂问题
    question = "在2015年到2018年期间,德国联邦议会中不同党派在难民家庭团聚问题上的讨论发生了怎样的变化?"
    state = create_initial_state(question)
    state = update_state(state, intent="complex", question_type="变化类")
    
    node = ExtractNode()
    result = node(state)
    
    print("=== 参数提取测试 ===")
    print(f"问题: {question}")
    print(f"提取参数:")
    print(json.dumps(result['parameters'], ensure_ascii=False, indent=2))
    print(f"是否拆解: {result['is_decomposed']}")
    print(f"下一节点: {result['next_node']}")
