"""
意图判断节点
判断用户问题是简单检索还是复杂分析
"""

from typing import Dict
from ...llm.client import GeminiLLMClient
from ...llm.prompts import PromptTemplates
from ...utils.logger import logger
from ..state import GraphState, update_state


class IntentNode:
    """
    意图判断节点
    
    功能:
    1. 分析问题复杂度
    2. 判断是否需要拆解
    3. 决定后续处理路径
    
    输出:
    - intent: "simple" 或 "complex"
    - complexity_analysis: 复杂度分析结果
    """
    
    def __init__(self, llm_client: GeminiLLMClient = None):
        """
        初始化意图判断节点
        
        Args:
            llm_client: LLM客户端,如果为None则自动创建
        """
        self.llm = llm_client or GeminiLLMClient()
        self.prompts = PromptTemplates()
        
    def __call__(self, state: GraphState) -> GraphState:
        """
        执行意图判断
        
        Args:
            state: 当前状态
            
        Returns:
            更新后的状态
        """
        question = state["question"]
        logger.info(f"[IntentNode] 开始判断问题意图: {question}")
        
        try:
            # 构建Prompt
            prompt = self.prompts.format_intent_prompt(question)
            
            # 调用LLM
            response = self.llm.invoke(prompt)
            
            logger.debug(f"[IntentNode] LLM响应: {response[:200]}...")
            
            # 解析响应
            intent, complexity_analysis = self._parse_response(response)
            
            logger.info(f"[IntentNode] 判断结果 - 意图: {intent}, 复杂度: {complexity_analysis[:50]}...")
            
            # 更新状态
            return update_state(
                state,
                intent=intent,
                complexity_analysis=complexity_analysis,
                current_node="intent",
                next_node="classify" if intent == "complex" else "extract"
            )
            
        except Exception as e:
            logger.error(f"[IntentNode] 意图判断失败: {str(e)}")
            return update_state(
                state,
                error=f"意图判断失败: {str(e)}",
                current_node="intent",
                next_node="exception"
            )
    
    def _parse_response(self, response: str) -> tuple[str, str]:
        """
        解析LLM响应
        
        Args:
            response: LLM响应文本
            
        Returns:
            (intent, complexity_analysis)
        """
        # 默认值
        intent = "simple"
        complexity_analysis = response
        
        # 简单的规则解析
        response_lower = response.lower()
        
        # 判断意图
        if "复杂" in response or "complex" in response_lower or "需要拆解" in response:
            intent = "complex"
        elif "简单" in response or "simple" in response_lower or "直接检索" in response:
            intent = "simple"
        else:
            # 根据关键词进一步判断
            complex_keywords = ["多个维度", "对比", "趋势", "变化", "总结", "分析"]
            if any(kw in response for kw in complex_keywords):
                intent = "complex"
        
        return intent, complexity_analysis


if __name__ == "__main__":
    # 测试意图判断节点
    from ..state import create_initial_state
    
    # 测试简单问题
    simple_question = "2019年德国联邦议院讨论了哪些主要议题?"
    state = create_initial_state(simple_question)
    
    node = IntentNode()
    result = node(state)
    
    print("=== 简单问题测试 ===")
    print(f"问题: {simple_question}")
    print(f"意图: {result['intent']}")
    print(f"分析: {result['complexity_analysis'][:100]}...")
    print(f"下一节点: {result['next_node']}")
    
    # 测试复杂问题
    complex_question = "在2015年到2018年期间,德国联邦议会中不同党派在难民家庭团聚问题上的讨论发生了怎样的变化?"
    state = create_initial_state(complex_question)
    
    result = node(state)
    
    print("\n=== 复杂问题测试 ===")
    print(f"问题: {complex_question}")
    print(f"意图: {result['intent']}")
    print(f"分析: {result['complexity_analysis'][:100]}...")
    print(f"下一节点: {result['next_node']}")
