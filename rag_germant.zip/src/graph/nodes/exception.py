"""
异常处理节点
处理无材料、错误等异常情况
"""

from ...llm.prompts import PromptTemplates
from ...utils.logger import logger
from ..state import GraphState, update_state


class ExceptionNode:
    """
    异常处理节点
    
    功能:
    1. 处理未找到材料的情况
    2. 处理系统错误
    3. 提供友好的错误提示和建议
    
    输出:
    - final_answer: 错误提示和建议
    """
    
    def __init__(self):
        """初始化异常处理节点"""
        self.prompts = PromptTemplates()
        
    def __call__(self, state: GraphState) -> GraphState:
        """
        处理异常
        
        Args:
            state: 当前状态
            
        Returns:
            更新后的状态
        """
        question = state["question"]
        error = state.get("error")
        no_material_found = state.get("no_material_found", False)
        
        logger.warning(f"[ExceptionNode] 处理异常 - 问题: {question}")
        
        if error:
            logger.error(f"[ExceptionNode] 系统错误: {error}")
            final_answer = self._handle_system_error(question, error)
        elif no_material_found:
            logger.warning(f"[ExceptionNode] 未找到材料")
            final_answer = self._handle_no_material(question)
        else:
            logger.warning(f"[ExceptionNode] 未知异常")
            final_answer = self._handle_unknown_error(question)
        
        # 更新状态
        return update_state(
            state,
            final_answer=final_answer,
            current_node="exception",
            next_node="end"
        )
    
    def _handle_no_material(self, question: str) -> str:
        """
        处理未找到材料
        
        Args:
            question: 用户问题
            
        Returns:
            错误提示
        """
        # 使用预定义的Prompt模板
        answer = self.prompts.format_no_material_prompt(question)
        
        return answer
    
    def _handle_system_error(self, question: str, error: str) -> str:
        """
        处理系统错误
        
        Args:
            question: 用户问题
            error: 错误信息
            
        Returns:
            错误提示
        """
        answer = f"""抱歉,处理您的问题时遇到了系统错误。

您的问题: {question}

错误信息: {error}

建议:
- 请稍后重试
- 如果问题持续,请简化您的问题
- 或者联系系统管理员

我们会尽快修复此问题。
"""
        return answer
    
    def _handle_unknown_error(self, question: str) -> str:
        """
        处理未知错误
        
        Args:
            question: 用户问题
            
        Returns:
            错误提示
        """
        answer = f"""抱歉,处理您的问题时遇到了未知问题。

您的问题: {question}

建议:
- 请尝试重新表述您的问题
- 确保问题表述清晰完整
- 或者尝试将问题拆分为多个简单问题

如需帮助,可以参考以下示例问题:
- "2019年德国联邦议院讨论了哪些主要议题?"
- "CDU/CSU在2020年对气候保护的立场是什么?"
- "请总结Merkel在2019年关于欧盟一体化的主要观点"
"""
        return answer


if __name__ == "__main__":
    # 测试异常处理节点
    from ..state import create_initial_state, update_state
    
    # 测试未找到材料
    question1 = "1900年德国联邦议院讨论了什么?"
    state1 = create_initial_state(question1)
    state1 = update_state(state1, no_material_found=True)
    
    node = ExceptionNode()
    result1 = node(state1)
    
    print("=== 未找到材料测试 ===")
    print(f"问题: {question1}")
    print(f"\n答案:\n{result1['final_answer']}")
    
    # 测试系统错误
    question2 = "2019年德国联邦议院讨论了什么?"
    state2 = create_initial_state(question2)
    state2 = update_state(state2, error="数据库连接失败")
    
    result2 = node(state2)
    
    print("\n=== 系统错误测试 ===")
    print(f"问题: {question2}")
    print(f"\n答案:\n{result2['final_answer']}")
