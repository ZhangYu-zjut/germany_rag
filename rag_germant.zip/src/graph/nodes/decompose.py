"""
问题拆解节点
将复杂问题拆解为多个子问题
"""

from typing import List, Dict, Optional
from ...llm.client import GeminiLLMClient
from ...llm.prompts import PromptTemplates
from ...utils.logger import logger
from ..state import GraphState, update_state


class DecomposeNode:
    """
    问题拆解节点
    
    功能:
    1. 根据问题类型选择拆解策略
    2. 模板化拆解(变化类/对比类/总结类)
    3. 自由拆解(其他类型)
    
    输出:
    - sub_questions: 子问题列表
    """
    
    def __init__(self, llm_client: GeminiLLMClient = None):
        """
        初始化问题拆解节点
        
        Args:
            llm_client: LLM客户端,如果为None则自动创建
        """
        self.llm = llm_client or GeminiLLMClient()
        self.prompts = PromptTemplates()
        
    def __call__(self, state: GraphState) -> GraphState:
        """
        执行问题拆解
        
        Args:
            state: 当前状态
            
        Returns:
            更新后的状态
        """
        question = state["question"]
        question_type = state.get("question_type", "")
        parameters = state.get("parameters", {})
        
        logger.info(f"[DecomposeNode] 开始拆解问题: {question}")
        logger.info(f"[DecomposeNode] 问题类型: {question_type}")
        
        try:
            # 选择拆解策略
            if question_type in ["变化类", "对比类", "总结类"]:
                sub_questions = self._template_decompose(question, question_type, parameters)
            else:
                sub_questions = self._free_decompose(question)
            
            logger.info(f"[DecomposeNode] 拆解为 {len(sub_questions)} 个子问题")
            for i, sq in enumerate(sub_questions, 1):
                logger.debug(f"  {i}. {sq}")
            
            # 更新状态
            return update_state(
                state,
                sub_questions=sub_questions,
                current_node="decompose",
                next_node="retrieve"
            )
            
        except Exception as e:
            logger.error(f"[DecomposeNode] 问题拆解失败: {str(e)}")
            # 如果拆解失败,使用原问题
            return update_state(
                state,
                sub_questions=[question],
                current_node="decompose",
                next_node="retrieve"
            )
    
    def _template_decompose(
        self,
        question: str,
        question_type: str,
        parameters: Dict
    ) -> List[str]:
        """
        模板化拆解
        
        Args:
            question: 原问题
            question_type: 问题类型
            parameters: 提取的参数
            
        Returns:
            子问题列表
        """
        logger.info(f"[DecomposeNode] 使用模板化拆解: {question_type}")
        
        sub_questions = []
        
        # 提取关键参数
        time_range = parameters.get("time_range", {})
        parties = parameters.get("parties", [])
        topics = parameters.get("topics", [])
        keywords = parameters.get("keywords", [])
        
        # 获取年份列表
        years = time_range.get("specific_years", [])
        if not years:
            start = time_range.get("start_year")
            end = time_range.get("end_year")
            if start and end:
                years = [str(y) for y in range(int(start), int(end) + 1)]
        
        # 根据问题类型拆解
        if question_type == "变化类":
            # 变化类: 按年份×党派拆解
            sub_questions = self._decompose_change_type(years, parties, topics, keywords)
            
        elif question_type == "对比类":
            # 对比类: 按党派×时间段拆解
            sub_questions = self._decompose_compare_type(years, parties, topics, keywords)
            
        elif question_type == "总结类":
            # 总结类: 按主题×时间拆解
            sub_questions = self._decompose_summary_type(years, parties, topics, keywords)
        
        # 如果模板拆解失败,使用LLM拆解
        if not sub_questions:
            logger.warning("[DecomposeNode] 模板拆解无结果,转用LLM拆解")
            prompt = self.prompts.format_decomposition_prompt(
                question,
                question_type,
                parameters,
                use_template=True
            )
            response = self.llm.invoke(prompt)
            sub_questions = self._parse_sub_questions(response)
        
        return sub_questions
    
    def _decompose_change_type(
        self,
        years: List[str],
        parties: List[str],
        topics: List[str],
        keywords: List[str]
    ) -> List[str]:
        """
        变化类问题拆解: 按年份×党派
        
        Args:
            years: 年份列表
            parties: 党派列表
            topics: 主题列表
            keywords: 关键词列表
            
        Returns:
            子问题列表
        """
        sub_questions = []
        
        topic_str = "、".join(topics) if topics else "、".join(keywords[:2]) if keywords else "该议题"
        
        if years and parties:
            # 按年份×党派拆解
            for year in years:
                for party in parties:
                    sub_questions.append(
                        f"{year}年{party}在{topic_str}上的立场是什么?"
                    )
        elif years:
            # 只按年份拆解
            for year in years:
                sub_questions.append(
                    f"{year}年德国联邦议院在{topic_str}上的讨论情况如何?"
                )
        elif parties:
            # 只按党派拆解
            for party in parties:
                sub_questions.append(
                    f"{party}在{topic_str}上的立场是什么?"
                )
        
        return sub_questions
    
    def _decompose_compare_type(
        self,
        years: List[str],
        parties: List[str],
        topics: List[str],
        keywords: List[str]
    ) -> List[str]:
        """
        对比类问题拆解: 按党派×时间段
        
        Args:
            years: 年份列表
            parties: 党派列表
            topics: 主题列表
            keywords: 关键词列表
            
        Returns:
            子问题列表
        """
        sub_questions = []
        
        topic_str = "、".join(topics) if topics else "、".join(keywords[:2]) if keywords else "该议题"
        time_str = f"{years[0]}-{years[-1]}年" if len(years) > 1 else f"{years[0]}年" if years else ""
        
        if parties:
            # 为每个党派单独提问
            for party in parties:
                if time_str:
                    sub_questions.append(
                        f"{time_str}{party}在{topic_str}上的立场是什么?"
                    )
                else:
                    sub_questions.append(
                        f"{party}在{topic_str}上的立场是什么?"
                    )
        
        return sub_questions
    
    def _decompose_summary_type(
        self,
        years: List[str],
        parties: List[str],
        topics: List[str],
        keywords: List[str]
    ) -> List[str]:
        """
        总结类问题拆解: 按主题×时间
        
        Args:
            years: 年份列表
            parties: 党派列表
            topics: 主题列表
            keywords: 关键词列表
            
        Returns:
            子问题列表
        """
        sub_questions = []
        
        time_str = f"{years[0]}-{years[-1]}年" if len(years) > 1 else f"{years[0]}年" if years else ""
        
        if topics:
            # 按主题拆解
            for topic in topics:
                if parties:
                    for party in parties:
                        sub_questions.append(
                            f"{time_str}{party}在{topic}上的主要观点是什么?"
                        )
                else:
                    sub_questions.append(
                        f"{time_str}德国联邦议院在{topic}上的主要观点是什么?"
                    )
        elif keywords:
            # 按关键词拆解
            for keyword in keywords[:3]:  # 限制关键词数量
                sub_questions.append(
                    f"{time_str}德国联邦议院关于{keyword}的主要讨论内容是什么?"
                )
        
        return sub_questions
    
    def _free_decompose(self, question: str) -> List[str]:
        """
        自由拆解(使用LLM)
        
        Args:
            question: 原问题
            
        Returns:
            子问题列表
        """
        logger.info("[DecomposeNode] 使用自由拆解")
        
        # 构建Prompt
        prompt = self.prompts.format_decomposition_prompt(
            question,
            use_template=False
        )
        
        # 调用LLM
        response = self.llm.invoke(prompt)
        
        # 解析子问题
        sub_questions = self._parse_sub_questions(response)
        
        return sub_questions
    
    def _parse_sub_questions(self, response: str) -> List[str]:
        """
        从LLM响应中解析子问题列表
        
        Args:
            response: LLM响应
            
        Returns:
            子问题列表
        """
        sub_questions = []
        
        # 按行分割
        lines = response.strip().split('\n')
        
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            # 移除序号
            # 支持格式: "1. 问题", "1) 问题", "- 问题", "• 问题"
            line = line.lstrip('0123456789.-) •')
            line = line.strip()
            
            if line and len(line) > 5:  # 过滤太短的行
                sub_questions.append(line)
        
        # 如果解析失败,返回原问题
        if not sub_questions:
            logger.warning("[DecomposeNode] 未能解析出子问题")
        
        return sub_questions


if __name__ == "__main__":
    # 测试问题拆解节点
    from ..state import create_initial_state, update_state
    
    # 测试变化类问题
    question = "在2015年到2018年期间,德国联邦议会中不同党派在难民家庭团聚问题上的讨论发生了怎样的变化?"
    state = create_initial_state(question)
    state = update_state(
        state,
        intent="complex",
        question_type="变化类",
        parameters={
            "time_range": {
                "start_year": "2015",
                "end_year": "2018",
                "specific_years": ["2015", "2016", "2017", "2018"]
            },
            "parties": ["CDU/CSU", "SPD", "GRÜNE"],
            "topics": ["难民", "家庭团聚"],
            "keywords": ["Flüchtlinge", "Familiennachzug"]
        }
    )
    
    node = DecomposeNode()
    result = node(state)
    
    print("=== 变化类问题拆解测试 ===")
    print(f"原问题: {question}")
    print(f"\n子问题 ({len(result['sub_questions'])}个):")
    for i, sq in enumerate(result['sub_questions'], 1):
        print(f"{i}. {sq}")
    print(f"\n下一节点: {result['next_node']}")
