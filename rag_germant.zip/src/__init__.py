"""
德国议会智能问答RAG系统
主模块初始化
"""

__version__ = "0.1.0"
__author__ = "AI Assistant"
__description__ = "German Parliament RAG Q&A System"
