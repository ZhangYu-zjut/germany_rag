"""
工具模块初始化
"""

from .logger import logger

__all__ = ["logger"]
