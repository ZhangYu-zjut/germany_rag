"""
配置模块初始化
"""

from .settings import settings, Settings

__all__ = ["settings", "Settings"]
