# Milvus 运行方式详解 & Collection 概念说明

## 📚 目录
1. [Milvus 是什么？](#1-milvus-是什么)
2. [Collection 是什么？](#2-collection-是什么)
3. [三种运行方式对比](#3-三种运行方式对比)
4. [推荐：使用 Milvus Lite (无需 Docker)](#4-推荐使用-milvus-lite-无需-docker)
5. [详细使用指南](#5-详细使用指南)

---

## 1️⃣ Milvus 是什么？

**Milvus** 是一个开源的**向量数据库**，专门用于存储和检索高维向量数据。

### 🤔 为什么需要向量数据库？

在我们的德国议会智能问答系统中：

```
用户问题: "2019年德国联邦议院讨论了哪些主要议题?"
           ↓
    转换为向量(Embedding)
           ↓
    [0.1, 0.3, -0.2, ..., 0.5]  (1536维向量)
           ↓
    在Milvus中搜索相似向量
           ↓
    找到最相关的演讲记录
           ↓
    返回答案
```

**传统数据库** (MySQL, PostgreSQL)：
- ❌ 只能精确匹配关键词
- ❌ 无法理解语义
- ❌ 搜索 "气候保护" 不会找到 "环境政策"

**向量数据库** (Milvus)：
- ✅ 理解语义相似性
- ✅ 搜索 "气候保护" 可以找到 "环境政策"、"碳排放"
- ✅ 速度快，支持亿级向量检索

---

## 2️⃣ Collection 是什么？

### 📦 Collection = 表格 (类比传统数据库)

在传统数据库中：
```
数据库 (Database)
  └── 表 (Table)
       ├── 列 (Column)
       └── 行 (Row)
```

在 Milvus 中：
```
Milvus
  └── Collection (类似表)
       ├── 字段 (Field)
       │    ├── id (主键)
       │    ├── vector (向量字段，1536维)
       │    ├── text (文本内容)
       │    ├── year (年份)
       │    ├── speaker (发言人)
       │    └── group (党派)
       └── 实体 (Entity，类似行)
```

### 🎯 我们的 Collection

**名称**: `parliament_speeches` (德国议会演讲)

**包含内容**:
```python
{
    "id": 1,
    "vector": [0.1, 0.3, -0.2, ..., 0.5],  # 1536维向量
    "text": "我们今天讨论气候保护政策...",
    "year": "2019",
    "month": "03",
    "day": "15",
    "speaker": "Merkel",
    "group": "CDU/CSU",
    "group_chinese": "基民盟/基社盟",
    # ... 更多字段
}
```

### 📊 Collection 的作用

1. **组织数据**: 将所有演讲向量组织在一起
2. **定义结构**: 规定每条记录包含哪些字段
3. **创建索引**: 建立索引加速向量检索
4. **支持查询**: 支持向量检索和元数据过滤

---

## 3️⃣ 三种运行方式对比

### 方式一：Milvus Lite ⭐ **推荐用于开发**

```
优点:
✅ 无需 Docker
✅ 安装简单 (pip install milvus-lite)
✅ 启动快速
✅ 适合开发和测试
✅ 数据存储在本地文件

缺点:
⚠️ 性能不如完整版
⚠️ 功能略有限制
⚠️ 不适合生产环境
```

**适用场景**:
- 本地开发
- 功能测试
- 快速原型验证
- 个人学习

### 方式二：Milvus Standalone (Docker) 🐳

```
优点:
✅ 功能完整
✅ 性能优秀
✅ 适合中小规模生产
✅ 易于部署

缺点:
⚠️ 需要 Docker 环境
⚠️ 需要更多资源
⚠️ 启动稍慢
```

**适用场景**:
- 中小规模生产环境
- 团队开发
- 性能测试

### 方式三：Milvus Cloud ☁️

```
优点:
✅ 无需管理服务器
✅ 自动扩展
✅ 高可用性
✅ 适合大规模生产

缺点:
⚠️ 需要付费
⚠️ 依赖网络
⚠️ 配置复杂
```

**适用场景**:
- 大规模生产环境
- 需要高可用
- 数据量巨大

---

## 4️⃣ 推荐：使用 Milvus Lite (无需 Docker)

### 📝 配置步骤

#### 第 1 步：安装依赖

```bash
# 重新安装依赖（已包含 milvus-lite）
pip install -r requirements.txt
```

#### 第 2 步：修改 `.env` 配置

`.env` 文件已经自动更新为：

```bash
# Milvus模式: lite/local/cloud
MILVUS_MODE=lite  # ✅ 使用 Milvus Lite

# Milvus Lite配置(无需Docker)
MILVUS_LITE_PATH=./milvus_data/milvus_lite.db
```

#### 第 3 步：运行系统

```bash
# 直接运行，无需启动 Docker
python build_index.py  # 构建索引
python main.py          # 启动问答系统
```

### 🎉 就这么简单！

不需要：
- ❌ 安装 Docker
- ❌ 启动 Milvus 容器
- ❌ 配置端口映射
- ❌ 管理容器生命周期

只需要：
- ✅ 安装 Python 包
- ✅ 运行 Python 脚本

---

## 5️⃣ 详细使用指南

### 🚀 完整流程演示

#### 场景：从零开始使用 Milvus Lite

```bash
# 1. 确保已安装依赖
pip install -r requirements.txt

# 2. 检查配置
cat .env | grep MILVUS_MODE
# 输出应该是: MILVUS_MODE=lite

# 3. 运行环境检查
python check_env.py

# 4. 构建索引（首次运行）
python build_index.py
```

**build_index.py 做了什么？**

```
1. 加载数据 (pp_2019.json, pp_2020.json, pp_2021.json)
   ↓
2. 文本分块 (1000字符/chunk)
   ↓
3. 生成向量 (使用 Gemini Embedding)
   ↓
4. 创建 Collection (parliament_speeches)
   ↓
5. 插入向量到 Milvus Lite
   ↓
6. 创建索引 (加速检索)
   ↓
完成！数据存储在: ./milvus_data/milvus_lite.db
```

#### 运行主程序

```bash
python main.py
```

**输出示例**:

```
正在初始化系统...
[Workflow] 开始初始化工作流...
连接Milvus Lite: ./milvus_data/milvus_lite.db
Milvus连接成功: mode=lite
Collection存在 (包含2156条记录)
✅ 系统初始化成功

请输入问题: 2019年德国联邦议院讨论了哪些主要议题?

正在处理您的问题...
[IntentNode] 判断结果 - 意图: simple
[RetrieveNode] 检索问题: 2019年德国联邦议院讨论了哪些主要议题?
[RetrieveNode] 找到 5 个相关chunks
[SummarizeNode] 总结完成

答案:
根据检索到的材料,2019年德国联邦议院讨论的主要议题包括:
1. 气候保护政策
2. 数字化转型
3. 社会公平与养老金改革
...
```

---

### 📊 数据存储位置

#### Milvus Lite 模式

```
项目目录/
├── milvus_data/           # ✅ Milvus Lite 数据目录
│   └── milvus_lite.db    # 向量数据库文件
├── data/
│   └── pp_json_49-21/    # 原始 JSON 数据
└── logs/
    └── app.log           # 日志文件
```

**查看数据库大小**:
```bash
# Windows PowerShell
Get-ChildItem -Recurse milvus_data | Measure-Object -Property Length -Sum

# Linux/Mac
du -sh milvus_data/
```

---

### 🔄 切换运行模式

#### 从 Milvus Lite 切换到 Docker

```bash
# 1. 修改 .env
MILVUS_MODE=local  # 改为 local

# 2. 启动 Docker Milvus
docker run -d --name milvus -p 19530:19530 milvusdb/milvus:latest

# 3. 重新构建索引
python build_index.py
```

#### 从 Docker 切换回 Milvus Lite

```bash
# 1. 修改 .env
MILVUS_MODE=lite  # 改为 lite

# 2. 重新运行（无需 Docker）
python main.py
```

---

### 🧪 测试不同模式

#### 测试脚本

创建 `test_milvus_modes.py`:

```python
"""测试不同 Milvus 模式"""

from src.vectordb import MilvusClient
from src.config import settings

def test_connection():
    print(f"当前模式: {settings.milvus_mode}")
    print(f"连接URI: {settings.milvus_uri}")
    
    try:
        with MilvusClient() as client:
            collections = client.list_collections()
            print(f"✅ 连接成功")
            print(f"Collections: {collections}")
    except Exception as e:
        print(f"❌ 连接失败: {e}")

if __name__ == "__main__":
    test_connection()
```

运行测试:
```bash
python test_milvus_modes.py
```

---

### 📖 常见问题解答

#### Q1: Milvus Lite 性能如何？

**答**: 
- 小数据量(<10万向量): ⭐⭐⭐⭐⭐ 优秀
- 中等数据量(10-100万): ⭐⭐⭐⭐ 良好
- 大数据量(>100万): ⭐⭐⭐ 一般（建议用 Docker）

我们的项目（2.1万条记录）使用 Milvus Lite **完全够用**！

#### Q2: Milvus Lite 的数据会丢失吗？

**答**: 不会！数据持久化存储在 `./milvus_data/milvus_lite.db`

#### Q3: 可以同时使用多种模式吗？

**答**: 不建议。每种模式的数据是独立的，切换模式后需要重新构建索引。

#### Q4: 如何备份数据？

**Milvus Lite**:
```bash
# 备份数据库文件
cp -r milvus_data milvus_data_backup

# 恢复
cp -r milvus_data_backup milvus_data
```

**Docker Milvus**:
```bash
# 导出数据
docker exec milvus milvus-backup create

# 恢复数据
docker exec milvus milvus-backup restore
```

#### Q5: 如何删除 Collection？

```python
from pymilvus import utility, connections
from src.config import settings

# 连接
connections.connect(uri=settings.milvus_uri)

# 删除 Collection
utility.drop_collection("parliament_speeches")

# 重新构建
# python build_index.py
```

---

### 🎓 学习资源

- **Milvus 官方文档**: https://milvus.io/docs
- **Milvus Lite 介绍**: https://milvus.io/docs/milvus_lite.md
- **向量数据库原理**: https://zilliz.com/learn/what-is-vector-database

---

## 📝 总结

### ✅ 推荐配置（开发/个人使用）

```bash
# .env
MILVUS_MODE=lite
MILVUS_LITE_PATH=./milvus_data/milvus_lite.db
```

**优点**:
- 无需 Docker
- 安装简单
- 启动快速
- 完全满足项目需求

### 🎯 关键概念回顾

1. **Milvus** = 向量数据库（专门存储和检索向量）
2. **Collection** = 表格（存储向量和元数据的容器）
3. **Milvus Lite** = 轻量级版本（无需 Docker）
4. **向量** = 文本的数学表示（1536维数组）

### 🚀 快速开始命令

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 运行检查
python check_env.py

# 3. 构建索引
python build_index.py

# 4. 启动系统
python main.py
```

---

**现在您完全不需要 Docker 了！** 🎉
